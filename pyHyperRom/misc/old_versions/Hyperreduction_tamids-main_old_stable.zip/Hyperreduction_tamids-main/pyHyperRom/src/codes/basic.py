"""
This module imports some commonly used librarires.
You can use ``from pyHyperRom.basic import *``
to use the most frequently used libraries.
"""
import numpy as np
import matplotlib.pyplot as plt
import time as time
import random
from scipy import sparse
from scipy.sparse import linalg
from matplotlib import cm
from matplotlib.ticker import LinearLocator
import fnnlsEigen as fe #nnls
import sympy as sp
from itertools import product
from mpl_toolkits.mplot3d import Axes3D
import os